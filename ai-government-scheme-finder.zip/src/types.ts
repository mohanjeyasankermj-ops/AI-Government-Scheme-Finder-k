export interface UserProfile {
  name: string;
  age: number;
  gender: string;
  state: string;
  occupation: string;
  annualIncome: number;
  category: string;
  disability: boolean;
}

export interface Scheme {
  id: string;
  name: string;
  nameTamil: string;
  ministry: string;
  category: string; // "Central" | "State"
  objective: string;
  benefits: string;
  eligibilityWhy?: string;
  eligibilityCriteria?: string;
  documents: string[];
  howToApply: string;
  sourceUrl?: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
}

export interface UploadAnalysisResult {
  schemeName: string;
  schemeNameTamil: string;
  ministry: string;
  mainObjective: string;
  keyBenefits: string;
  eligibilityCriteriaSummary: string;
  citizenEligibilityStatus: string; // "Eligible" | "Not Eligible" | "Undetermined"
  citizenEligibilityExplanation: string;
  stepsToApply: string;
  criticalDates: string;
}

// English and Tamil Localization Strings
export const TRANSLATIONS: Record<string, Record<string, string>> = {
  en: {
    appTitle: "AI Government Scheme Finder",
    appSubtitle: "Discover and apply for eligible government schemes instantly with Gemini AI",
    tagline: "Your Personal Bridge to Government Welfare & Support",
    oneLinePitch: "Helping every citizen instantly discover eligible welfare benefits in their preferred language.",
    
    // Navigation
    home: "Home",
    finder: "Eligibility Finder",
    search: "Live Search",
    upload: "New Scheme Analyzer",
    chat: "Sevai AI Chat",
    contact: "Contact & Feedback",
    
    // Hero & Stats
    getStarted: "Find My Eligible Schemes",
    searchPlaceholder: "Search for agriculture, student, business, or girl-child schemes...",
    curatedTitle: "Curated Key Schemes",
    activeSchemes: "Active Schemes",
    verifiedCitizens: "Citizens Served",
    statesCovered: "States & UTs",
    directBenefit: "Direct Support",
    languageSwitch: "தமிழ்",
    
    // Profile form
    profileTitle: "Enter Your Profile Details",
    profileSubtitle: "Provide basic details to let Gemini AI find your perfect government scheme matches.",
    fullName: "Name (Optional)",
    age: "Age",
    gender: "Gender",
    state: "State / UT",
    occupation: "Occupation",
    annualIncome: "Annual Income (₹)",
    category: "Social Category",
    disability: "Person with Disability (PwD)",
    disabilityYes: "Yes",
    disabilityNo: "No",
    findSchemesBtn: "Analyze Eligibility with Gemini AI",
    analyzingText: "Gemini AI is analyzing your profile and matchmaking...",
    
    // Genders
    male: "Male",
    female: "Female",
    transgender: "Transgender",
    other: "Other",

    // Occupations
    student: "Student",
    farmer: "Farmer / Agricultural Worker",
    unemployed: "Unemployed",
    employee: "Salaried Employee",
    selfEmployed: "Self Employed / Micro Business",
    seniorCitizen: "Retired / Senior Citizen",
    homemaker: "Homemaker",
    laborer: "Daily Wage Laborer",
    
    // Categories
    general: "General",
    obc: "OBC",
    sc: "Scheduled Caste (SC)",
    st: "Scheduled Tribe (ST)",
    
    // Results
    resultsTitle: "Your Eligible Schemes",
    resultsSubtitle: "Based on your unique profile, Gemini AI recommends these active welfare programs.",
    whyEligible: "Why You Are Eligible",
    requiredDocs: "Required Documents",
    howToApply: "How to Apply",
    categoryCentral: "Central Scheme",
    categoryState: "State Scheme",
    benefitLabel: "Benefit Details",
    downloadPDF: "Download Report (PDF/Print)",
    printTitle: "Government Scheme Finder - Personalized Eligibility Report",
    
    // Scheme upload analyzer
    uploadTitle: "Analyze New Scheme Document",
    uploadSubtitle: "Pasted a new scheme notice, PDF text, or newspaper clipping. Gemini AI will analyze it against your profile!",
    pasteLabel: "Paste Government Order (G.O.) or Scheme Notice Text",
    pastePlaceholder: "Paste the raw text of any newly published government scheme notification or news clipping here...",
    analyzeUploadBtn: "Parse and Match Eligibility",
    uploadResultsTitle: "AI Policy Analysis",
    eligibilityStatus: "Eligibility Verdict",
    verdictEligible: "Eligible - You qualify!",
    verdictNotEligible: "Not Eligible - You do not qualify.",
    verdictUndetermined: "Undetermined - Missing profile data",
    criticalDates: "Critical Dates & Deadlines",
    stepsLabel: "Actionable Application Steps",
    
    // Chatbot
    chatTitle: "Ask Sevai AI",
    chatSubtitle: "Chat with our empathetic AI regarding any central/state government scheme or criteria.",
    chatPlaceholder: "Ask me anything (e.g., 'What schemes are there for girl students in Tamil Nadu?')",
    chatSend: "Send",
    chatWelcome: "Hello! I am Sevai AI, your government schemes assistant. Ask me questions about schemes, eligibility criteria, or how to get documents!",
    
    // Live Search Page
    searchTitle: "Live Global Scheme Search",
    searchPageSubtitle: "Enter keywords. Gemini AI will search Google Search live and structure results instantly.",
    noResults: "No schemes found yet. Try searching for a welfare topic above!",
    searchingLive: "Searching Google Search live via Gemini...",
    
    // Contact Page
    contactTitle: "Contact & Feedbacks",
    contactSubtitle: "Help us improve this portal or request support with eligibility assessments.",
    yourEmail: "Your Email Address",
    feedbackMsg: "Feedback or Inquiry Message",
    submitFeedback: "Send Feedback",
    feedbackSuccess: "Thank you! Your feedback has been simulated and saved to our logs.",
    pitchLabel: "Hackathon Pitch:"
  },
  ta: {
    appTitle: "ஏஐ அரசு திட்டங்கள் கண்டறிவி",
    appSubtitle: "ஜெமினி ஏஐ மூலம் உங்களுக்கான அரசு நலத்திட்டங்களை உடனடியாகக் கண்டறியுங்கள்",
    tagline: "மக்களுக்கான அரசு நலத்திட்டங்களின் எளிய வழிகாட்டி",
    oneLinePitch: "ஒவ்வொரு குடிமகனும் தங்களுக்குத் தகுதியான அரசுத் திட்டங்களை தங்களின் சொந்த மொழியில் எளிதாகக் கண்டறிய உதவுகிறது.",
    
    // Navigation
    home: "முகப்பு",
    finder: "தகுதி கண்டறிவி",
    search: "நேரடி தேடல்",
    upload: "புதிய திட்ட பகுப்பாய்வு",
    chat: "சேவை ஏஐ அரட்டை",
    contact: "தொடர்பு & கருத்து",
    
    // Hero & Stats
    getStarted: "எனது திட்டங்களைக் கண்டறி",
    searchPlaceholder: "விவசாயம், கல்வி, தொழில் அல்லது பெண்களுக்கான திட்டங்களைத் தேடுங்கள்...",
    curatedTitle: "முக்கியத் திட்டங்கள்",
    activeSchemes: "செயலில் உள்ள திட்டங்கள்",
    verifiedCitizens: "பயன்பெற்ற குடிமக்கள்",
    statesCovered: "மாநிலங்கள் & யூனியன் பிரதேசங்கள்",
    directBenefit: "நேரடி உதவி",
    languageSwitch: "English",
    
    // Profile form
    profileTitle: "உங்கள் விவரங்களைப் பதிவு செய்யவும்",
    profileSubtitle: "ஜெமினி ஏஐ உங்களுக்குப் பொருத்தமான அரசுத் திட்டங்களைக் கண்டறிய உங்கள் அடிப்படை விவரங்களை உள்ளிடவும்.",
    fullName: "பெயர் (விருப்பத்திற்குரியது)",
    age: "வயது",
    gender: "பாலினம்",
    state: "மாநிலம்",
    occupation: "தொழில்",
    annualIncome: "ஆண்டு வருமானம் (₹)",
    category: "சமூகப் பிரிவு",
    disability: "மாற்றுத்திறனாளியா?",
    disabilityYes: "ஆம்",
    disabilityNo: "இல்லை",
    findSchemesBtn: "ஜெமினி ஏஐ தகுதி ஆய்வு செய்க",
    analyzingText: "ஜெமினி ஏஐ உங்கள் சுயவிவரத்தை ஆய்வு செய்து பொருத்தமான திட்டங்களைத் தேடுகிறது...",
    
    // Genders
    male: "ஆண்",
    female: "பெண்",
    transgender: "திருநங்கை / திருநம்பி",
    other: "மற்றவை",

    // Occupations
    student: "மாணவர்",
    farmer: "விவசாயி / விவசாயத் தொழிலாளி",
    unemployed: "வேலைவாய்ப்பற்றவர்",
    employee: "மாதாந்திர ஊழியர்",
    selfEmployed: "சுயதொழில் / சிறு வணிகர்",
    seniorCitizen: "ஓய்வூதியதாரர் / மூத்த குடிமகன்",
    homemaker: "இல்லத்தரசி",
    laborer: "தினக்கூலித் தொழிலாளி",
    
    // Categories
    general: "பொதுப் பிரிவு (General)",
    obc: "இதர பிற்படுத்தப்பட்ட வகுப்பினர் (OBC)",
    sc: "பட்டியல் வகுப்பினர் (SC)",
    st: "பழங்குடியினர் (ST)",
    
    // Results
    resultsTitle: "உங்களுக்குத் தகுதியான திட்டங்கள்",
    resultsSubtitle: "உங்கள் சுயவிவரத்தின் அடிப்படையில் ஜெமினி ஏஐ பரிந்துரைக்கும் செயலில் உள்ள திட்டங்கள்.",
    whyEligible: "நீங்கள் தகுதி பெறுவதற்கான காரணம்",
    requiredDocs: "தேவையான ஆவணங்கள்",
    howToApply: "விண்ணப்பிக்கும் முறை",
    categoryCentral: "மத்திய அரசுத் திட்டம்",
    categoryState: "மாநில அரசுத் திட்டம்",
    benefitLabel: "திட்டத்தின் பயன்கள்",
    downloadPDF: "அறிக்கையைப் பதிவிறக்கு (PDF/அச்சு)",
    printTitle: "அரசுத் திட்டங்கள் கண்டறிவி - தனிப்பயனாக்கப்பட்ட தகுதி அறிக்கை",
    
    // Scheme upload analyzer
    uploadTitle: "புதிய திட்ட அறிவிப்பு பகுப்பாய்வு",
    uploadSubtitle: "புதிய திட்ட அரசாணை அல்லது செய்தித்தாள் துணுக்கின் உரையை நகலெடுத்து ஒட்டவும். ஜெமினி ஏஐ அதை உங்கள் சுயவிவரத்துடன் ஒப்பிட்டு பகுப்பாய்வு செய்யும்!",
    pasteLabel: "அரசாணை (G.O.) அல்லது திட்ட அறிவிப்பு உரையை ஒட்டுக",
    pastePlaceholder: "புதிய அரசுத் திட்ட அறிவிப்பின் உரையை இங்கே ஒட்டவும்...",
    analyzeUploadBtn: "பகுப்பாய்வு செய்து தகுதியைச் சரிபார்",
    uploadResultsTitle: "ஏஐ திட்ட பகுப்பாய்வு",
    eligibilityStatus: "தகுதித் தீர்ப்பு",
    verdictEligible: "தகுதியுடையவர் - நீங்கள் விண்ணப்பிக்கலாம்!",
    verdictNotEligible: "தகுதி இல்லை - உங்களுக்குப் பொருந்தாது.",
    verdictUndetermined: "தீர்மானிக்க முடியாதது - சுயவிவர விவரங்கள் இல்லை",
    criticalDates: "முக்கிய தேதிகள் & காலக்கெடு",
    stepsLabel: "விண்ணப்பிப்பதற்கான வழிமுறைகள்",
    
    // Chatbot
    chatTitle: "சேவை ஏஐ-யிடம் கேளுங்கள்",
    chatSubtitle: "எந்தவொரு மத்திய/மாநில அரசுத் திட்டம் அல்லது தகுதி பற்றி எங்களின் ஏஐ உதவியாளரிடம் அரட்டை அடிக்கவும்.",
    chatPlaceholder: "ஏதேனும் கேளுங்கள் (உதாரணமாக, 'தமிழ்நாட்டில் மாணவிகளுக்கு என்ன திட்டங்கள் உள்ளன?')",
    chatSend: "அனுப்பு",
    chatWelcome: "வணக்கம்! நான் சேவை ஏஐ அரசு திட்டங்கள் உதவியாளர். திட்டங்கள், தகுதி வரம்புகள் அல்லது ஆவணங்களை எவ்வாறு பெறுவது என்பது குறித்து என்னிடம் கேளுங்கள்!",
    
    // Live Search Page
    searchTitle: "நேரடி திட்டத் தேடல்",
    searchPageSubtitle: "தேடல் சொற்களை உள்ளிடுக. ஜெமினி ஏஐ கூகிள் தேடலில் நேரலையில் தேடி உடனடியாகத் திட்டங்களை வடிவமைத்துக் கொடுக்கும்.",
    noResults: "திட்டங்கள் எதுவும் தேடப்படவில்லை. மேலே உள்ள தேடல் பட்டியில் ஏதேனும் ஒரு நலத்திட்டப் பிரிவைத் தேடுங்கள்!",
    searchingLive: "ஜெமினி மூலம் கூகுளில் நேரலையாகத் தேடப்படுகிறது...",
    
    // Contact Page
    contactTitle: "தொடர்பு & கருத்து",
    contactSubtitle: "இந்தத் தளத்தை மேம்படுத்த உதவ உங்கள் கருத்துக்களைப் பகிருங்கள்.",
    yourEmail: "உங்கள் மின்னஞ்சல் முகவரி",
    feedbackMsg: "கருத்து அல்லது வினவல் செய்தி",
    submitFeedback: "கருத்தை அனுப்பு",
    feedbackSuccess: "நன்றி! உங்கள் கருத்துப் பதிவு செய்யப்பட்டு எங்கள் கணினிப் பதிவேட்டில் சேமிக்கப்பட்டது.",
    pitchLabel: "ஹேக்கத்தான் பிட்ச்:"
  }
};
