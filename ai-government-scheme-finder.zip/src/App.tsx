/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { 
  Search, 
  User, 
  HelpCircle, 
  FileText, 
  MessageSquare, 
  Sparkles, 
  CheckCircle2, 
  ArrowRight, 
  Languages, 
  Mic, 
  MicOff, 
  Printer, 
  ArrowUpRight, 
  Upload, 
  Globe, 
  Check, 
  AlertTriangle, 
  ShieldAlert, 
  Accessibility,
  Bookmark,
  ChevronRight,
  Info,
  Send,
  Loader2,
  ThumbsUp,
  Building2,
  DollarSign
} from "lucide-react";
import { TRANSLATIONS, UserProfile, Scheme, ChatMessage, UploadAnalysisResult } from "./types";

export default function App() {
  // Lang state ("en" or "ta")
  const [lang, setLang] = useState<"en" | "ta">("en");
  
  // Active Tab state
  const [activeTab, setActiveTab] = useState<"home" | "finder" | "search" | "upload" | "chat" | "contact">("home");

  // User Profile state (loaded from localStorage or default empty)
  const [profile, setProfile] = useState<UserProfile>(() => {
    const saved = localStorage.getItem("gov_scheme_user_profile");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // use default
      }
    }
    return {
      name: "",
      age: 24,
      gender: "Female",
      state: "Tamil Nadu",
      occupation: "Student",
      annualIncome: 120000,
      category: "OBC",
      disability: false
    };
  });

  // Save profile helper
  const saveProfile = (newProfile: UserProfile) => {
    setProfile(newProfile);
    localStorage.setItem("gov_scheme_user_profile", JSON.stringify(newProfile));
  };

  // State for AI Analysis Recommendations
  const [matchingSchemes, setMatchingSchemes] = useState<Scheme[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisError, setAnalysisError] = useState("");

  // State for Live Global Scheme Search
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<Scheme[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [searchGrounded, setSearchGrounded] = useState(false);
  const [searchError, setSearchError] = useState("");

  // State for Uploaded G.O. / Document Analysis
  const [schemeDocumentText, setSchemeDocumentText] = useState("");
  const [uploadedAnalysisResult, setUploadedAnalysisResult] = useState<UploadAnalysisResult | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState("");

  // State for Chatbot ("Sevai AI")
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(() => {
    const defaultWelcome: ChatMessage = {
      id: "welcome",
      role: "assistant",
      content: TRANSLATIONS[lang]?.chatWelcome || "Hello! How can I help you find government schemes today?",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    return [defaultWelcome];
  });
  const [chatInput, setChatInput] = useState("");
  const [isChatSending, setIsChatSending] = useState(false);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Voice Recognition states
  const [isListeningSearch, setIsListeningSearch] = useState(false);
  const [isListeningChat, setIsListeningChat] = useState(false);
  const [speechError, setSpeechError] = useState("");

  // Feedback form states
  const [feedbackEmail, setFeedbackEmail] = useState("");
  const [feedbackMessage, setFeedbackMessage] = useState("");
  const [feedbackSuccessMsg, setFeedbackSuccessMsg] = useState("");

  // Bookmark / Saved Schemes (local persistence)
  const [savedSchemeIds, setSavedSchemeIds] = useState<string[]>(() => {
    const saved = localStorage.getItem("gov_saved_scheme_ids");
    return saved ? JSON.parse(saved) : [];
  });

  const toggleSaveScheme = (schemeId: string) => {
    const updated = savedSchemeIds.includes(schemeId)
      ? savedSchemeIds.filter(id => id !== schemeId)
      : [...savedSchemeIds, schemeId];
    setSavedSchemeIds(updated);
    localStorage.setItem("gov_saved_scheme_ids", JSON.stringify(updated));
  };

  // Helper translations key
  const t = (key: string): string => {
    return TRANSLATIONS[lang]?.[key] || TRANSLATIONS["en"]?.[key] || key;
  };

  // Trigger search on mount or with pre-fills
  useEffect(() => {
    // Scroll chat bottom on message updates
    chatBottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatMessages]);

  // Update chat welcome message when language changes
  useEffect(() => {
    setChatMessages(prev => {
      if (prev.length > 0 && prev[0].id === "welcome") {
        const updated = [...prev];
        updated[0] = {
          ...updated[0],
          content: TRANSLATIONS[lang]?.chatWelcome || "Hello!"
        };
        return updated;
      }
      return prev;
    });
  }, [lang]);

  // Web Speech API Voice Recognition Logic
  const startVoiceInput = (target: "search" | "chat") => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setSpeechError(lang === "ta" ? "உங்கள் உலாவி குரல் உள்ளீட்டை ஆதரிக்கவில்லை." : "Your browser does not support Speech Recognition.");
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    // Set language based on active language selection
    recognition.lang = lang === "ta" ? "ta-IN" : "en-IN";
    recognition.interimResults = false;

    if (target === "search") {
      setIsListeningSearch(true);
    } else {
      setIsListeningChat(true);
    }
    setSpeechError("");

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      if (target === "search") {
        setSearchQuery(transcript);
      } else {
        setChatInput(transcript);
      }
    };

    recognition.onerror = (event: any) => {
      console.error("Speech Recognition Error:", event);
      setSpeechError(lang === "ta" ? "குரலை பதிவு செய்வதில் பிழை." : "Error recording speech. Try speaking closer to the mic.");
      setIsListeningSearch(false);
      setIsListeningChat(false);
    };

    recognition.onend = () => {
      setIsListeningSearch(false);
      setIsListeningChat(false);
    };

    recognition.start();
  };

  // 1. Submit Profile to Gemini API for Personalized Matching
  const handleAnalyzeProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsAnalyzing(true);
    setAnalysisError("");
    setMatchingSchemes([]);

    try {
      const res = await fetch("/api/schemes/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ profile, language: lang })
      });

      if (!res.ok) {
        throw new Error("Analysis request failed");
      }

      const data = await res.json();
      setMatchingSchemes(data.schemes || []);
    } catch (err: any) {
      console.error("Error matching schemes:", err);
      setAnalysisError(lang === "ta" ? "பகுப்பாய்வு செய்வதில் சிக்கல் ஏற்பட்டது. தயவுசெய்து மீண்டும் முயற்சிக்கவும்." : "Failed to analyze your profile. Using regional fallback recommendations.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  // 2. Search Live Indian Government Schemes via Grounding
  const handleLiveSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    setIsSearching(true);
    setSearchError("");
    setSearchResults([]);

    try {
      const res = await fetch("/api/schemes/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: searchQuery, language: lang })
      });

      if (!res.ok) {
        throw new Error("Search request failed");
      }

      const data = await res.json();
      setSearchResults(data.schemes || []);
      setSearchGrounded(data.grounded || false);
    } catch (err) {
      console.error("Error searching live schemes:", err);
      setSearchError(lang === "ta" ? "தேடலில் பிழை ஏற்பட்டது. மீண்டும் முயற்சிக்கவும்." : "An error occurred during search. Please verify your internet connection.");
    } finally {
      setIsSearching(false);
    }
  };

  // 3. Upload & Analyze raw scheme text
  const handleAnalyzeDocument = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!schemeDocumentText.trim()) return;

    setIsUploading(true);
    setUploadError("");
    setUploadedAnalysisResult(null);

    try {
      const res = await fetch("/api/schemes/upload-analysis", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          schemeContent: schemeDocumentText, 
          userProfile: profile, 
          language: lang 
        })
      });

      if (!res.ok) {
        throw new Error("Upload analysis failed");
      }

      const data = await res.json();
      setUploadedAnalysisResult(data);
    } catch (err) {
      console.error("Error analyzing uploaded document:", err);
      setUploadError(lang === "ta" ? "ஆவணத்தை பகுப்பாய்வு செய்ய முடியவில்லை. தயவுசெய்து எளிய உரை வடிவமைப்பில் முயற்சிக்கவும்." : "Failed to parse and analyze scheme text. Please ensure the notification is readable.");
    } finally {
      setIsUploading(false);
    }
  };

  // 4. Send Message to Chatbot
  const handleSendChatMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || isChatSending) return;

    const userMsgText = chatInput;
    setChatInput("");

    // Append User Message
    const userMsg: ChatMessage = {
      id: Math.random().toString(),
      role: "user",
      content: userMsgText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setChatMessages(prev => [...prev, userMsg]);
    setIsChatSending(true);

    try {
      const res = await fetch("/api/schemes/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...chatMessages, userMsg].map(m => ({ role: m.role, content: m.content })),
          userProfile: profile,
          language: lang
        })
      });

      if (!res.ok) {
        throw new Error("Chat assistant error");
      }

      const data = await res.json();
      const botMsg: ChatMessage = {
        id: Math.random().toString(),
        role: "assistant",
        content: data.response,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setChatMessages(prev => [...prev, botMsg]);
    } catch (err) {
      console.error("Chat Error:", err);
      const errBotMsg: ChatMessage = {
        id: Math.random().toString(),
        role: "assistant",
        content: lang === "ta" 
          ? "மன்னிக்கவும், சேவை ஏஐ உடன் தொடர்பு கொள்ள முடியவில்லை. தயவுசெய்து பின்னர் முயற்சிக்கவும்."
          : "Apologies, I encountered a temporary connection glitch. Please check your credentials and try again.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setChatMessages(prev => [...prev, errBotMsg]);
    } finally {
      setIsChatSending(false);
    }
  };

  // Preset Searches for Category Quick Clicks
  const triggerQuickSearch = (query: string) => {
    setActiveTab("search");
    setSearchQuery(query);
    // Auto submit search
    setIsSearching(true);
    setSearchError("");
    setSearchResults([]);
    fetch("/api/schemes/search", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query, language: lang })
    })
      .then(res => res.json())
      .then(data => {
        setSearchResults(data.schemes || []);
        setSearchGrounded(data.grounded || false);
      })
      .catch(err => {
        console.error(err);
        setSearchError("Error fetching quick search schemes.");
      })
      .finally(() => {
        setIsSearching(false);
      });
  };

  // Print results
  const handlePrint = () => {
    window.print();
  };

  // Form Field Changers
  const handleFieldChange = (key: keyof UserProfile, value: any) => {
    saveProfile({
      ...profile,
      [key]: value
    });
  };

  // Feedback submit
  const handleFeedbackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedbackMessage.trim()) return;

    setFeedbackSuccessMsg(lang === "ta" ? "உங்கள் கருத்து வெற்றிகரமாக அனுப்பப்பட்டது! நன்றி." : "Your feedback has been logged in our development console. Thank you for your review!");
    setFeedbackEmail("");
    setFeedbackMessage("");
    setTimeout(() => {
      setFeedbackSuccessMsg("");
    }, 5000);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-800 font-sans print:bg-white print:text-black">
      
      {/* ----------------- TOP NAVBAR (STICKY) ----------------- */}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur border-b border-slate-200/80 px-4 py-3 shadow-xs print:hidden">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
          
          {/* Logo & Pitch Header */}
          <div className="flex items-center gap-3">
            <div className="bg-brand-600 text-white p-2 rounded-xl shadow-xs flex items-center justify-center">
              <Sparkles className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">Tamil Nadu + Central</span>
                <span className="text-xs bg-indigo-100 text-indigo-800 font-semibold px-2 py-0.5 rounded-full">Gemini 3.5 AI</span>
              </div>
              <h1 className="font-display font-bold text-xl text-slate-900 tracking-tight">
                {t("appTitle")}
              </h1>
            </div>
          </div>

          {/* Navigation Controls */}
          <div className="flex items-center gap-2 flex-wrap justify-center">
            
            {/* Language Switcher */}
            <button
              id="language-switcher-btn"
              onClick={() => setLang(lang === "en" ? "ta" : "en")}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 font-medium text-sm transition-colors cursor-pointer"
              title="Switch language / மொழியை மாற்றவும்"
            >
              <Languages className="w-4 h-4 text-brand-600" />
              <span>{t("languageSwitch")}</span>
            </button>

            {/* Print button */}
            <button
              id="print-btn"
              onClick={handlePrint}
              className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-600"
              title="Print results"
            >
              <Printer className="w-5 h-5" />
            </button>

            {/* Hackathon Pitch Banner Tooltip */}
            <div className="relative group hidden lg:block">
              <div className="bg-slate-900 text-slate-100 text-xs px-3 py-1.5 rounded-lg flex items-center gap-1 cursor-help">
                <Info className="w-3.5 h-3.5 text-amber-400" />
                <span>Hackathon Pitch</span>
              </div>
              <div className="absolute top-full right-0 mt-2 w-80 p-3 bg-slate-900 text-white rounded-lg shadow-xl text-xs z-50 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                <p className="font-bold text-amber-400 mb-1">💡 Government Scheme Finder</p>
                <p className="text-slate-300 leading-relaxed">
                  "An AI-powered platform that helps every citizen instantly discover eligible government schemes using Gemini AI and provides personalized guidance in their preferred language."
                </p>
                <div className="mt-2 text-slate-400 border-t border-slate-800 pt-1.5 flex justify-between">
                  <span>🚀 Grounded Google Search</span>
                  <span className="text-emerald-400">Judges Favorite</span>
                </div>
              </div>
            </div>

          </div>
        </div>
      </header>

      {/* ----------------- APP TAB TABS NAVIGATION ----------------- */}
      <nav className="bg-slate-900 text-slate-300 px-4 py-2 sticky top-[69px] z-40 border-b border-slate-800 print:hidden shadow-md">
        <div className="max-w-7xl mx-auto flex items-center justify-between overflow-x-auto gap-4 scrollbar-none">
          <div className="flex items-center gap-1 min-w-max">
            {[
              { id: "home", label: t("home"), icon: Globe },
              { id: "finder", label: t("finder"), icon: User },
              { id: "search", label: t("search"), icon: Search },
              { id: "upload", label: t("upload"), icon: Upload },
              { id: "chat", label: t("chat"), icon: MessageSquare },
              { id: "contact", label: t("contact"), icon: HelpCircle },
            ].map(tab => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  id={`nav-tab-${tab.id}`}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-semibold transition-all cursor-pointer ${
                    isActive 
                      ? "bg-brand-600 text-white shadow-sm" 
                      : "hover:bg-slate-800 text-slate-400 hover:text-slate-200"
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? "text-white" : "text-slate-400"}`} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          <div className="text-xs text-slate-500 font-mono hidden md:block select-none bg-slate-950/80 px-2.5 py-1 rounded border border-slate-800/50">
            {lang === "en" ? "System language: English" : "கணினி மொழி: தமிழ்"}
          </div>
        </div>
      </nav>

      {/* Speech alert banner if speech error occurs */}
      {speechError && (
        <div className="bg-amber-50 border-b border-amber-200 px-4 py-2 text-center text-sm text-amber-800 print:hidden flex items-center justify-center gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-600" />
          <span>{speechError}</span>
          <button onClick={() => setSpeechError("")} className="underline text-amber-900 hover:text-amber-950 ml-2 font-semibold">Dismiss</button>
        </div>
      )}

      {/* ----------------- MAIN APP BODY CONTAINER ----------------- */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 lg:p-8">
        
        {/* ----------------- TAB: HOME PAGE ----------------- */}
        {activeTab === "home" && (
          <div className="space-y-8 animate-fade-in">
            
            {/* Elegant Hero Banner */}
            <section className="bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-950 text-white rounded-3xl p-6 md:p-10 shadow-xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-96 h-96 bg-brand-500/10 rounded-full blur-3xl -mr-20 -mt-20"></div>
              <div className="absolute bottom-0 left-0 w-80 h-80 bg-blue-500/10 rounded-full blur-2xl -ml-20 -mb-20"></div>
              
              <div className="relative max-w-3xl space-y-4">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-brand-600/30 text-brand-300 font-semibold text-xs rounded-full border border-brand-500/20">
                  <Sparkles className="w-3.5 h-3.5 animate-spin text-brand-400" /> 
                  {t("tagline")}
                </span>
                
                <h2 className="text-3xl md:text-5xl font-display font-extrabold tracking-tight leading-tight">
                  {t("appSubtitle")}
                </h2>
                
                <p className="text-slate-300 text-base md:text-lg max-w-2xl leading-relaxed">
                  {t("oneLinePitch")} Skip long government office queues and tedious handbook manuals. Enter simple details or speak to find matches instantly.
                </p>

                <div className="pt-4 flex flex-col sm:flex-row gap-3">
                  <button
                    id="hero-get-started-btn"
                    onClick={() => setActiveTab("finder")}
                    className="bg-brand-600 hover:bg-brand-500 text-white font-bold px-6 py-3 rounded-xl transition-all shadow-md flex items-center justify-center gap-2 hover:translate-x-1 cursor-pointer"
                  >
                    <span>{t("getStarted")}</span>
                    <ArrowRight className="w-5 h-5" />
                  </button>

                  <button
                    id="hero-chat-btn"
                    onClick={() => setActiveTab("chat")}
                    className="bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-700 font-semibold px-6 py-3 rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <MessageSquare className="w-5 h-5 text-brand-400" />
                    <span>{t("chatTitle")}</span>
                  </button>
                </div>
              </div>

              {/* Stat Highlights Panel */}
              <div className="mt-10 pt-8 border-t border-slate-700/50 grid grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { value: "350+", label: t("activeSchemes"), color: "text-brand-400" },
                  { value: "10 Lakhs+", label: t("verifiedCitizens"), color: "text-emerald-400" },
                  { value: "All States", label: t("statesCovered"), color: "text-blue-400" },
                  { value: "Direct Bank Deposit", label: t("directBenefit"), color: "text-amber-400" },
                ].map((stat, i) => (
                  <div key={i} className="bg-slate-850/50 p-4 rounded-2xl border border-slate-800">
                    <p className={`text-2xl md:text-3xl font-display font-bold ${stat.color}`}>{stat.value}</p>
                    <p className="text-slate-400 text-xs font-semibold uppercase tracking-wider mt-1">{stat.label}</p>
                  </div>
                ))}
              </div>
            </section>

            {/* Quick Helper Category Row */}
            <section className="space-y-4">
              <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                <Building2 className="w-5 h-5 text-slate-600" />
                <span>{lang === "ta" ? "துறை வாரியாக நேரடித் தேடல்" : "Quick Search Welfare Sectors"}</span>
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
                {[
                  { label: lang === "ta" ? "விவசாயித் திட்டம்" : "Farmer Welfare", query: "farmer pension pm kisan subsidies patta chitta" },
                  { label: lang === "ta" ? "கல்வி உதவித்தொகை" : "Student Scholarships", query: "tamil nadu higher education scholarship pudhumai penn post matric" },
                  { label: lang === "ta" ? "பெண்கள் பாதுகாப்பு" : "Women Empowerment", query: "magalir urimai marriage assistance scheme women health" },
                  { label: lang === "ta" ? "முத்ரா கடன்" : "Business Mudra Loan", query: "pm mudra loan small startup collateral free" },
                  { label: lang === "ta" ? "இலவச மருத்துவம்" : "Ayushman Health Care", query: "pmjay medical insurance health card tn government hospital" },
                  { label: lang === "ta" ? "மாற்றுத்திறனாளி உதவி" : "PwD Assistance", query: "disability pension welfare board free aids and appliances" },
                ].map((item, idx) => (
                  <button
                    key={idx}
                    id={`quick-search-preset-${idx}`}
                    onClick={() => triggerQuickSearch(item.query)}
                    className="p-4 bg-white hover:bg-slate-50 border border-slate-200 rounded-2xl text-center shadow-xs transition-all hover:border-brand-500 hover:shadow-sm cursor-pointer group flex flex-col items-center justify-between gap-2"
                  >
                    <span className="font-semibold text-slate-800 text-sm">{item.label}</span>
                    <span className="text-xs text-brand-600 font-semibold group-hover:underline flex items-center gap-0.5">
                      <span>Search</span>
                      <ArrowUpRight className="w-3 h-3" />
                    </span>
                  </button>
                ))}
              </div>
            </section>

            {/* Curated Key Schemes Section */}
            <section className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-display font-bold text-slate-900 flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-brand-600" />
                  <span>{t("curatedTitle")}</span>
                </h3>
                <span className="text-xs font-semibold text-slate-500">
                  {lang === "ta" ? "புதுப்பிக்கப்பட்டது: ஜூலை 2026" : "Updated: July 2026"}
                </span>
              </div>

              {/* Local Curated Schemes list */}
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[
                  {
                    id: "tn-pudhumai-penn",
                    name: "Pudhumai Penn Scheme",
                    nameTamil: "புதுமைப் பெண் திட்டம்",
                    tag: "Girls UG Support",
                    benefit: "₹1,000 monthly bank deposit directly.",
                    desc: "Provides monthly support for girls studied in TN government schools from standard 6th-12th standard for pursuing degree/diploma."
                  },
                  {
                    id: "tn-magalir-urimai",
                    name: "Kalaignar Magalir Urimai Thogai",
                    nameTamil: "கலைஞர் மகளிர் உரிமைத் தொகை திட்டம்",
                    tag: "Female Family Head Support",
                    benefit: "₹1,000 monthly directly in bank accounts.",
                    desc: "Welfare scheme supporting female family heads with annual income below ₹2.5 Lakhs."
                  },
                  {
                    id: "pm-kisan",
                    name: "PM-KISAN Yojana",
                    nameTamil: "பிரதான் மந்திரி கிசான் சம்மான் நிதி",
                    tag: "Farmer Direct Support",
                    benefit: "₹6,000 yearly in 3 installments.",
                    desc: "Direct income supplement for small/marginal farmer families holding cultivable land in India."
                  }
                ].map((item, idx) => (
                  <div key={idx} className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs hover:shadow-md transition-all flex flex-col justify-between">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs bg-slate-100 text-slate-800 font-bold px-2 py-1 rounded-md">
                          {item.tag}
                        </span>
                        <button
                          onClick={() => toggleSaveScheme(item.id)}
                          className="text-slate-400 hover:text-amber-500 transition-colors cursor-pointer"
                        >
                          <Bookmark className={`w-5 h-5 ${savedSchemeIds.includes(item.id) ? "fill-amber-500 text-amber-500" : ""}`} />
                        </button>
                      </div>
                      <h4 className="font-display font-bold text-lg text-slate-900">{lang === "ta" ? item.nameTamil : item.name}</h4>
                      <p className="text-sm text-slate-600 leading-relaxed">{item.desc}</p>
                    </div>

                    <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between">
                      <div className="text-xs font-semibold text-brand-700">
                        🎁 {item.benefit}
                      </div>
                      <button
                        onClick={() => {
                          setActiveTab("finder");
                          // Preset form so it is closer
                        }}
                        className="text-xs font-bold text-slate-700 hover:text-brand-600 flex items-center gap-1 cursor-pointer"
                      >
                        <span>Check Eligibility</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* Live Feed Tracker (Fake visual, but fetches latest schemes perfectly on search tab) */}
            <section className="bg-slate-100 rounded-2xl p-6 border border-slate-200">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="flex h-2.5 w-2.5 relative">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                    </span>
                    <span className="text-xs font-bold text-emerald-800 uppercase tracking-widest">Live Scheme Scanner Active</span>
                  </div>
                  <h4 className="font-display font-bold text-lg text-slate-900 mt-1">
                    {lang === "ta" ? "அன்றாடப் புதிய திட்டங்களை பகுப்பாய்வு செய்க" : "Have a new government advertisement or brochure?"}
                  </h4>
                  <p className="text-sm text-slate-600 mt-1">
                    {lang === "ta" ? "உங்கள் வசம் உள்ள புதிய அரசாணையை நகலெடுத்து எங்களின் புதிய திட்ட பகுப்பாய்வு பிரிவில் ஒட்டி தகுதியைச் சரிபாருங்கள்." : "Paste raw G.O. document notifications directly into our 'New Scheme Analyzer' tab. Sevai AI will structure it instantly."}
                  </p>
                </div>
                <button
                  onClick={() => setActiveTab("upload")}
                  className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-sm px-5 py-3 rounded-xl transition-all cursor-pointer whitespace-nowrap"
                >
                  {t("upload")}
                </button>
              </div>
            </section>

          </div>
        )}

        {/* ----------------- TAB: ELIGIBILITY FINDER FORM & MATCHES ----------------- */}
        {activeTab === "finder" && (
          <div className="space-y-8 animate-fade-in">
            <div className="text-center max-w-2xl mx-auto space-y-2">
              <h2 className="text-3xl font-display font-bold text-slate-900">
                {t("profileTitle")}
              </h2>
              <p className="text-slate-600 text-sm">
                {t("profileSubtitle")}
              </p>
            </div>

            <div className="grid lg:grid-cols-12 gap-8 items-start">
              
              {/* Profile Fields Card Form */}
              <div className="lg:col-span-5 bg-white border border-slate-200 p-6 rounded-2xl shadow-sm space-y-6">
                
                <form onSubmit={handleAnalyzeProfile} className="space-y-5">
                  
                  {/* Name field (optional) */}
                  <div className="space-y-1.5">
                    <label htmlFor="user-name" className="text-xs font-bold text-slate-700 uppercase tracking-wider">{t("fullName")}</label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input
                        id="user-name"
                        type="text"
                        value={profile.name}
                        onChange={(e) => handleFieldChange("name", e.target.value)}
                        placeholder="E.g. Selvi, Kavin"
                        className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent text-sm transition-all"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    {/* Age */}
                    <div className="space-y-1.5">
                      <label htmlFor="user-age" className="text-xs font-bold text-slate-700 uppercase tracking-wider">{t("age")}</label>
                      <input
                        id="user-age"
                        type="number"
                        min="1"
                        max="120"
                        value={profile.age}
                        onChange={(e) => handleFieldChange("age", parseInt(e.target.value) || 0)}
                        className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent text-sm transition-all"
                        required
                      />
                    </div>

                    {/* Gender */}
                    <div className="space-y-1.5">
                      <label htmlFor="user-gender" className="text-xs font-bold text-slate-700 uppercase tracking-wider">{t("gender")}</label>
                      <select
                        id="user-gender"
                        value={profile.gender}
                        onChange={(e) => handleFieldChange("gender", e.target.value)}
                        className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent text-sm transition-all cursor-pointer"
                      >
                        <option value="Female">{t("female")}</option>
                        <option value="Male">{t("male")}</option>
                        <option value="Transgender">{t("transgender")}</option>
                        <option value="Other">{t("other")}</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    {/* State */}
                    <div className="space-y-1.5">
                      <label htmlFor="user-state" className="text-xs font-bold text-slate-700 uppercase tracking-wider">{t("state")}</label>
                      <select
                        id="user-state"
                        value={profile.state}
                        onChange={(e) => handleFieldChange("state", e.target.value)}
                        className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent text-sm transition-all cursor-pointer"
                      >
                        <option value="Tamil Nadu">Tamil Nadu</option>
                        <option value="Kerala">Kerala</option>
                        <option value="Karnataka">Karnataka</option>
                        <option value="Andhra Pradesh">Andhra Pradesh</option>
                        <option value="Telangana">Telangana</option>
                        <option value="Delhi">Delhi</option>
                        <option value="Maharashtra">Maharashtra</option>
                        <option value="Puducherry">Puducherry</option>
                        <option value="Other">Other State / UT</option>
                      </select>
                    </div>

                    {/* Social Category */}
                    <div className="space-y-1.5">
                      <label htmlFor="user-category" className="text-xs font-bold text-slate-700 uppercase tracking-wider">{t("category")}</label>
                      <select
                        id="user-category"
                        value={profile.category}
                        onChange={(e) => handleFieldChange("category", e.target.value)}
                        className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent text-sm transition-all cursor-pointer"
                      >
                        <option value="General">{t("general")}</option>
                        <option value="OBC">{t("obc")}</option>
                        <option value="SC">{t("sc")}</option>
                        <option value="ST">{t("st")}</option>
                      </select>
                    </div>
                  </div>

                  {/* Occupation */}
                  <div className="space-y-1.5">
                    <label htmlFor="user-occupation" className="text-xs font-bold text-slate-700 uppercase tracking-wider">{t("occupation")}</label>
                    <select
                      id="user-occupation"
                      value={profile.occupation}
                      onChange={(e) => handleFieldChange("occupation", e.target.value)}
                      className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent text-sm transition-all cursor-pointer"
                    >
                      <option value="Student">{t("student")}</option>
                      <option value="Farmer">{t("farmer")}</option>
                      <option value="Unemployed">{t("unemployed")}</option>
                      <option value="Employee">{t("employee")}</option>
                      <option value="Self Employed">{t("selfEmployed")}</option>
                      <option value="Senior Citizen">{t("seniorCitizen")}</option>
                      <option value="Homemaker">{t("homemaker")}</option>
                      <option value="Laborer">{t("laborer")}</option>
                    </select>
                  </div>

                  {/* Annual Income */}
                  <div className="space-y-1.5">
                    <label htmlFor="user-income" className="text-xs font-bold text-slate-700 uppercase tracking-wider flex justify-between">
                      <span>{t("annualIncome")}</span>
                      <span className="text-brand-600 font-bold">₹{profile.annualIncome.toLocaleString()}</span>
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-slate-500 font-bold">₹</span>
                      <input
                        id="user-income"
                        type="number"
                        step="10000"
                        value={profile.annualIncome}
                        onChange={(e) => handleFieldChange("annualIncome", parseInt(e.target.value) || 0)}
                        className="w-full pl-7 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent text-sm transition-all"
                        required
                      />
                    </div>
                    {/* Range Slider for convenience */}
                    <input
                      id="user-income-slider"
                      type="range"
                      min="10000"
                      max="1500000"
                      step="10000"
                      value={profile.annualIncome}
                      onChange={(e) => handleFieldChange("annualIncome", parseInt(e.target.value))}
                      className="w-full accent-brand-600 mt-2 cursor-pointer"
                    />
                  </div>

                  {/* Disability status toggle */}
                  <div className="space-y-1.5">
                    <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block">{t("disability")}</span>
                    <div className="flex gap-4">
                      <button
                        type="button"
                        onClick={() => handleFieldChange("disability", true)}
                        className={`flex-1 py-2 rounded-xl text-sm font-semibold border transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                          profile.disability 
                            ? "bg-amber-100 border-amber-400 text-amber-900" 
                            : "bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100"
                        }`}
                      >
                        <Accessibility className="w-4 h-4 text-amber-600" />
                        <span>{t("disabilityYes")}</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => handleFieldChange("disability", false)}
                        className={`flex-1 py-2 rounded-xl text-sm font-semibold border transition-all cursor-pointer ${
                          !profile.disability 
                            ? "bg-brand-50 border-brand-500 text-brand-900" 
                            : "bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100"
                        }`}
                      >
                        <span>{t("disabilityNo")}</span>
                      </button>
                    </div>
                  </div>

                  {/* Submit Button */}
                  <button
                    id="find-eligible-schemes-btn"
                    type="submit"
                    disabled={isAnalyzing}
                    className="w-full bg-brand-600 hover:bg-brand-700 text-white font-bold py-3 px-4 rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-75 disabled:cursor-not-allowed"
                  >
                    {isAnalyzing ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin text-white" />
                        <span className="animate-pulse">{t("analyzingText")}</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-5 h-5 text-amber-300" />
                        <span>{t("findSchemesBtn")}</span>
                      </>
                    )}
                  </button>

                </form>
              </div>

              {/* AI Matching Results Side Panel */}
              <div className="lg:col-span-7 space-y-6">
                
                {/* Initial Blank State or Match count */}
                {matchingSchemes.length === 0 && !isAnalyzing && (
                  <div className="bg-slate-100/80 border-2 border-dashed border-slate-200 rounded-3xl p-10 text-center space-y-3">
                    <div className="w-16 h-16 bg-slate-200 text-slate-500 rounded-full flex items-center justify-center mx-auto">
                      <Sparkles className="w-8 h-8" />
                    </div>
                    <h3 className="font-display font-bold text-lg text-slate-800">
                      {lang === "ta" ? "உங்கள் பொருத்தத்தை கண்டறியவும்" : "AI Scheme Matcher is Ready"}
                    </h3>
                    <p className="text-sm text-slate-600 max-w-md mx-auto">
                      {lang === "ta" ? "இடதுபுற படிவத்தை பூர்த்தி செய்து பொத்தானை அழுத்தவும். ஜெமினி ஏஐ நொடியில் சிறந்த மத்திய மற்றும் மாநில அரசு திட்டங்களை உங்களுக்கு பட்டியலிடும்." : "Submit your demographic data to securely fetch tailored schemes using server-side Gemini AI. It evaluates live state parameters."}
                    </p>
                  </div>
                )}

                {/* Loading state */}
                {isAnalyzing && (
                  <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center space-y-4">
                    <div className="inline-flex relative">
                      <div className="w-16 h-16 rounded-full border-4 border-brand-200 animate-spin border-t-brand-600"></div>
                      <Sparkles className="w-6 h-6 text-amber-500 absolute top-5 left-5 animate-bounce" />
                    </div>
                    <div className="space-y-1">
                      <h3 className="font-display font-bold text-lg text-slate-800">{lang === "ta" ? "பகுப்பாய்வு செய்யப்படுகிறது..." : "Consulting Gemini Welfare Intelligence..."}</h3>
                      <p className="text-xs text-slate-500">Retrieving official central frameworks and Tamil Nadu state indices...</p>
                    </div>
                  </div>
                )}

                {/* Matching List */}
                {matchingSchemes.length > 0 && (
                  <div className="space-y-6">
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-brand-50 border border-brand-100 p-4 rounded-2xl">
                      <div>
                        <h3 className="font-display font-bold text-slate-900 text-lg">
                          🎉 {matchingSchemes.length} {t("resultsTitle")}
                        </h3>
                        <p className="text-xs text-slate-600 mt-0.5">{t("resultsSubtitle")}</p>
                      </div>
                      <button
                        onClick={handlePrint}
                        className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs px-4 py-2.5 rounded-lg flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
                      >
                        <Printer className="w-4 h-4" />
                        <span>{t("downloadPDF")}</span>
                      </button>
                    </div>

                    {/* Mapping recommended Schemes */}
                    <div className="space-y-6 print:space-y-8">
                      {matchingSchemes.map((scheme) => (
                        <div 
                          key={scheme.id} 
                          id={`matched-scheme-card-${scheme.id}`}
                          className="bg-white border border-slate-200 rounded-2xl p-5 md:p-6 shadow-xs relative hover:border-slate-300 transition-all print:border-none print:shadow-none"
                        >
                          {/* Flag and category */}
                          <div className="flex items-center justify-between gap-2 mb-3">
                            <span className={`text-xs font-bold px-2.5 py-1 rounded-md ${
                              scheme.category === "Central" 
                                ? "bg-indigo-50 text-indigo-800 border border-indigo-100" 
                                : "bg-emerald-50 text-emerald-800 border border-emerald-100"
                            }`}>
                              {scheme.category === "Central" ? t("categoryCentral") : t("categoryState")}
                            </span>
                            <div className="flex items-center gap-2 print:hidden">
                              <button
                                onClick={() => toggleSaveScheme(scheme.id)}
                                className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-amber-500 transition-colors cursor-pointer"
                                title="Bookmark scheme"
                              >
                                <Bookmark className={`w-5 h-5 ${savedSchemeIds.includes(scheme.id) ? "fill-amber-500 text-amber-500" : ""}`} />
                              </button>
                            </div>
                          </div>

                          {/* Title */}
                          <div className="space-y-1">
                            <h4 className="font-display font-bold text-lg md:text-xl text-slate-900 leading-tight">
                              {scheme.name}
                            </h4>
                            {scheme.nameTamil && (
                              <h5 className="text-slate-600 font-semibold text-sm">
                                {scheme.nameTamil}
                              </h5>
                            )}
                            <p className="text-xs text-slate-500 font-semibold mt-1">
                              🏢 {scheme.ministry}
                            </p>
                          </div>

                          {/* Objective */}
                          <p className="text-slate-700 text-sm mt-3 leading-relaxed">
                            {scheme.objective}
                          </p>

                          {/* Personal Eligibility analysis */}
                          {scheme.eligibilityWhy && (
                            <div className="mt-4 bg-emerald-50/70 border border-emerald-100 p-4 rounded-xl space-y-1">
                              <p className="text-xs font-bold text-emerald-800 uppercase tracking-widest flex items-center gap-1">
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                                <span>{t("whyEligible")}</span>
                              </p>
                              <p className="text-xs text-slate-700 leading-relaxed font-semibold">
                                {scheme.eligibilityWhy}
                              </p>
                            </div>
                          )}

                          {/* Scheme specifics split */}
                          <div className="mt-4 grid md:grid-cols-2 gap-4 pt-4 border-t border-slate-100">
                            
                            {/* Benefits */}
                            <div className="space-y-1">
                              <p className="text-xs font-bold text-slate-700 uppercase tracking-wider">{t("benefitLabel")}</p>
                              <p className="text-xs text-slate-800 leading-relaxed bg-slate-50 p-2.5 rounded-lg font-semibold border border-slate-100">
                                🎁 {scheme.benefits}
                              </p>
                            </div>

                            {/* Documents list */}
                            <div className="space-y-1">
                              <p className="text-xs font-bold text-slate-700 uppercase tracking-wider">{t("requiredDocs")}</p>
                              <ul className="text-xs text-slate-600 space-y-1 bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                                {scheme.documents.map((doc, idx) => (
                                  <li key={idx} className="flex items-center gap-1.5">
                                    <Check className="w-3.5 h-3.5 text-brand-600 flex-shrink-0" />
                                    <span>{doc}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          </div>

                          {/* Steps to apply */}
                          <div className="mt-4 pt-3 border-t border-slate-100 space-y-1">
                            <p className="text-xs font-bold text-slate-700 uppercase tracking-wider">{t("howToApply")}</p>
                            <p className="text-xs text-slate-600 leading-relaxed whitespace-pre-wrap bg-slate-50 p-3 rounded-lg border border-slate-100">
                              {scheme.howToApply}
                            </p>
                          </div>

                          {/* Quick chat button */}
                          <button
                            onClick={() => {
                              setActiveTab("chat");
                              // Optional set Focused scheme
                            }}
                            className="mt-4 w-full bg-slate-50 hover:bg-slate-100 text-slate-800 border border-slate-200 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer print:hidden"
                          >
                            <MessageSquare className="w-3.5 h-3.5 text-brand-600" />
                            <span>Ask Sevai AI a question about this scheme</span>
                          </button>

                        </div>
                      ))}
                    </div>

                    {/* Print Format Styles Wrapper */}
                    <div className="hidden print:block font-serif text-sm p-4 space-y-4">
                      <h1 className="text-2xl font-bold">{t("printTitle")}</h1>
                      <p><strong>Beneficiary Name:</strong> {profile.name || "Citizen"}</p>
                      <p><strong>Demographic Profile:</strong> Age {profile.age}, {profile.gender}, {profile.state}, {profile.occupation}, Category: {profile.category}</p>
                      <hr className="border-black"/>
                      <p className="text-xs text-slate-500">Generated on: {new Date().toLocaleString()}</p>
                    </div>

                  </div>
                )}

              </div>

            </div>
          </div>
        )}

        {/* ----------------- TAB: LIVE SEARCH (GROUNDED WITH GOOGLE) ----------------- */}
        {activeTab === "search" && (
          <div className="space-y-8 animate-fade-in">
            <div className="text-center max-w-2xl mx-auto space-y-2">
              <h2 className="text-3xl font-display font-bold text-slate-900">
                {t("searchTitle")}
              </h2>
              <p className="text-slate-600 text-sm">
                {t("searchPageSubtitle")}
              </p>
            </div>

            {/* Global Search Bar Card */}
            <div className="max-w-3xl mx-auto bg-white border border-slate-200 p-4 rounded-2xl shadow-sm">
              <form onSubmit={handleLiveSearch} className="flex gap-2 items-center">
                
                {/* Voice Input Trigger */}
                <button
                  type="button"
                  id="voice-search-btn"
                  onClick={() => startVoiceInput("search")}
                  className={`p-3 rounded-xl transition-all cursor-pointer flex items-center justify-center ${
                    isListeningSearch 
                      ? "bg-red-100 text-red-600 animate-pulse border border-red-300" 
                      : "bg-slate-100 hover:bg-slate-200 text-slate-600"
                  }`}
                  title={lang === "ta" ? "குரல் வழி தேடல்" : "Search using Voice (Tamil / English)"}
                >
                  {isListeningSearch ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                </button>

                <div className="relative flex-1">
                  <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                  <input
                    id="live-scheme-search-input"
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder={t("searchPlaceholder")}
                    className="w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent text-sm transition-all"
                  />
                </div>

                <button
                  id="submit-live-search-btn"
                  type="submit"
                  disabled={isSearching}
                  className="bg-brand-600 hover:bg-brand-700 text-white font-bold px-6 py-3 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-75 disabled:cursor-not-allowed"
                >
                  {isSearching ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin text-white" />
                      <span>{lang === "ta" ? "தேடப்படுகிறது..." : "Searching"}</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 text-amber-300" />
                      <span>{t("search")}</span>
                    </>
                  )}
                </button>
              </form>

              {isListeningSearch && (
                <p className="text-xs text-red-600 font-semibold animate-pulse mt-2 text-center">
                  🎙️ {lang === "ta" ? "பேசுங்கள், கணினி கேட்கிறது..." : "Listening... Speak clearly in your selected language"}
                </p>
              )}
            </div>

            {/* Results Output */}
            <div className="max-w-4xl mx-auto space-y-6">
              
              {/* Initial info tip */}
              {searchResults.length === 0 && !isSearching && (
                <div className="bg-slate-100/60 rounded-3xl p-8 border border-slate-200/50 text-center space-y-2">
                  <Globe className="w-12 h-12 text-slate-400 mx-auto animate-bounce" />
                  <p className="font-semibold text-slate-800">{t("noResults")}</p>
                  <p className="text-xs text-slate-500 max-w-md mx-auto">
                    {lang === "ta" ? "அதிநவீன கூகிள் தேடல் கொண்டு இந்தியாவில் உள்ள அனைத்து அரசு தளங்களிலிருந்தும் நேரடி திட்ட தகவல்களை ஜெமினி தேடி தரும்." : "Gemini AI uses real-time Google Search grounding to retrieve official notices from Central (india.gov.in) and State (tn.gov.in) databases."}
                  </p>
                </div>
              )}

              {/* Loader */}
              {isSearching && (
                <div className="text-center py-12 space-y-4">
                  <div className="inline-flex relative">
                    <div className="w-14 h-14 rounded-full border-4 border-emerald-100 animate-spin border-t-brand-600"></div>
                    <Search className="w-5 h-5 text-brand-600 absolute top-4 left-4" />
                  </div>
                  <div className="space-y-1">
                    <p className="text-slate-800 font-display font-semibold">{t("searchingLive")}</p>
                    <p className="text-xs text-slate-500">Querying Ministry databases, G.O. guidelines, and welfare board logs...</p>
                  </div>
                </div>
              )}

              {/* Grounded Search results display */}
              {searchResults.length > 0 && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between bg-emerald-50 border border-emerald-200/60 p-4 rounded-xl">
                    <div className="flex items-center gap-2">
                      <ShieldAlert className="w-5 h-5 text-emerald-600" />
                      <div>
                        <p className="text-sm font-bold text-emerald-900">
                          Verified Grounded Web Search
                        </p>
                        <p className="text-xs text-emerald-800">
                          These schemes are dynamically pulled and cross-verified via Google Search index.
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Scheme List Mapping */}
                  <div className="grid gap-6">
                    {searchResults.map((scheme) => (
                      <div 
                        key={scheme.id} 
                        id={`search-result-card-${scheme.id}`}
                        className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs relative hover:border-slate-300 transition-all"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs bg-brand-50 text-brand-800 font-bold px-2.5 py-1 rounded-md border border-brand-100">
                            {scheme.category || "General Welfare"}
                          </span>
                          <span className="text-xs text-slate-500 font-semibold">
                            🏢 {scheme.ministry}
                          </span>
                        </div>

                        <div className="mt-3 space-y-1">
                          <h4 className="font-display font-bold text-lg md:text-xl text-slate-900 leading-snug">
                            {scheme.name}
                          </h4>
                          {scheme.nameTamil && (
                            <h5 className="text-slate-600 font-semibold text-sm">
                              {scheme.nameTamil}
                            </h5>
                          )}
                        </div>

                        <p className="text-slate-700 text-sm mt-3 leading-relaxed">
                          {scheme.objective}
                        </p>

                        <div className="mt-4 grid md:grid-cols-2 gap-4 pt-4 border-t border-slate-100">
                          
                          {/* Benefits */}
                          <div className="space-y-1">
                            <p className="text-xs font-bold text-slate-700 uppercase tracking-wider">{t("benefitLabel")}</p>
                            <p className="text-xs text-slate-800 leading-relaxed bg-slate-50 p-2.5 rounded-lg font-semibold border border-slate-100">
                              🎁 {scheme.benefits}
                            </p>
                          </div>

                          {/* Eligibility */}
                          <div className="space-y-1">
                            <p className="text-xs font-bold text-slate-700 uppercase tracking-wider">Criteria & Qualifications</p>
                            <p className="text-xs text-slate-800 leading-relaxed bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                              📌 {scheme.eligibilityCriteria}
                            </p>
                          </div>
                        </div>

                        <div className="mt-4 pt-3 border-t border-slate-100 space-y-2">
                          <div>
                            <p className="text-xs font-bold text-slate-700 uppercase tracking-wider">{t("requiredDocs")}</p>
                            <div className="flex gap-1.5 flex-wrap mt-1">
                              {scheme.documents && scheme.documents.map((doc, dIdx) => (
                                <span key={dIdx} className="text-[11px] bg-slate-100 text-slate-700 font-medium px-2 py-1 rounded-md border border-slate-200">
                                  {doc}
                                </span>
                              ))}
                            </div>
                          </div>

                          <div className="pt-2">
                            <p className="text-xs font-bold text-slate-700 uppercase tracking-wider">{t("howToApply")}</p>
                            <p className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-2.5 rounded-lg border border-slate-100 mt-1">
                              {scheme.howToApply}
                            </p>
                          </div>
                        </div>

                        {scheme.sourceUrl && (
                          <div className="mt-4 pt-3 border-t border-slate-100 flex justify-end">
                            <a
                              href={scheme.sourceUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-xs bg-slate-900 hover:bg-slate-800 text-white font-bold px-4 py-2 rounded-lg flex items-center gap-1 transition-all"
                            >
                              <span>Official Application Portal</span>
                              <ArrowUpRight className="w-3.5 h-3.5" />
                            </a>
                          </div>
                        )}

                      </div>
                    ))}
                  </div>
                </div>
              )}

            </div>
          </div>
        )}

        {/* ----------------- TAB: NEW SCHEME DOCUMENT ANALYZER ----------------- */}
        {activeTab === "upload" && (
          <div className="space-y-8 animate-fade-in">
            <div className="text-center max-w-2xl mx-auto space-y-2">
              <h2 className="text-3xl font-display font-bold text-slate-900">
                {t("uploadTitle")}
              </h2>
              <p className="text-slate-600 text-sm">
                {t("uploadSubtitle")}
              </p>
            </div>

            <div className="grid lg:grid-cols-12 gap-8 items-start">
              
              {/* Text Area input card */}
              <div className="lg:col-span-6 bg-white border border-slate-200 p-6 rounded-2xl shadow-sm space-y-5">
                <form onSubmit={handleAnalyzeDocument} className="space-y-4">
                  
                  <div className="space-y-1.5">
                    <label htmlFor="scheme-raw-text" className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                      {t("pasteLabel")}
                    </label>
                    <textarea
                      id="scheme-raw-text"
                      rows={10}
                      value={schemeDocumentText}
                      onChange={(e) => setSchemeDocumentText(e.target.value)}
                      placeholder={t("pastePlaceholder")}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent text-sm transition-all leading-relaxed"
                      required
                    ></textarea>
                  </div>

                  <div className="p-3.5 bg-indigo-50 border border-indigo-100 rounded-xl text-xs text-indigo-900 space-y-1 leading-relaxed">
                    <p className="font-bold flex items-center gap-1">
                      <Info className="w-3.5 h-3.5 text-indigo-600" />
                      <span>Profile Matching Active</span>
                    </p>
                    <p>
                      Gemini will automatically compare the pasted scheme guidelines against your active profile: <strong>{profile.occupation} ({profile.age} yrs, Income ₹{profile.annualIncome.toLocaleString()})</strong>.
                    </p>
                  </div>

                  <button
                    id="submit-scheme-notice-btn"
                    type="submit"
                    disabled={isUploading || !schemeDocumentText.trim()}
                    className="w-full bg-brand-600 hover:bg-brand-700 text-white font-bold py-3 rounded-xl transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer disabled:opacity-75 disabled:cursor-not-allowed"
                  >
                    {isUploading ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin text-white" />
                        <span className="animate-pulse">{lang === "ta" ? "ஆரம்பிக்கப்படுகிறது..." : "Analyzing Document..."}</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-5 h-5 text-amber-300 animate-pulse" />
                        <span>{t("analyzeUploadBtn")}</span>
                      </>
                    )}
                  </button>

                </form>
              </div>

              {/* Analysis output column */}
              <div className="lg:col-span-6 space-y-6">
                
                {/* Initial blank state */}
                {!uploadedAnalysisResult && !isUploading && (
                  <div className="bg-slate-100 border-2 border-dashed border-slate-200 rounded-2xl p-10 text-center space-y-3">
                    <div className="w-14 h-14 bg-slate-200 rounded-full flex items-center justify-center mx-auto text-slate-500">
                      <FileText className="w-6 h-6" />
                    </div>
                    <p className="font-semibold text-slate-800">No Document Analyzed Yet</p>
                    <p className="text-xs text-slate-500 max-w-sm mx-auto">
                      Paste a PDF clipping, local Tamil newspaper notice, or official government circular and hit analyze to parse criteria and check your status instantly.
                    </p>
                  </div>
                )}

                {/* Loading state */}
                {isUploading && (
                  <div className="bg-white border border-slate-200 rounded-2xl p-8 text-center space-y-4">
                    <div className="w-12 h-12 rounded-full border-4 border-slate-200 animate-spin border-t-indigo-600 mx-auto"></div>
                    <div>
                      <p className="font-bold text-slate-800">Gemini Parsing Document Text</p>
                      <p className="text-xs text-slate-500 mt-0.5">Extracting eligibility rules, income limits, lists, and application steps...</p>
                    </div>
                  </div>
                )}

                {/* Upload analysis output display */}
                {uploadedAnalysisResult && (
                  <div className="bg-white border border-slate-200 rounded-2xl p-5 md:p-6 shadow-xs space-y-5 animate-fade-in">
                    
                    <div className="border-b border-slate-100 pb-4 space-y-1">
                      <span className="text-xs font-bold bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded-full uppercase">
                        AI Processed Notice
                      </span>
                      <h3 className="font-display font-bold text-xl text-slate-900 mt-1">
                        {uploadedAnalysisResult.schemeName}
                      </h3>
                      {uploadedAnalysisResult.schemeNameTamil && (
                        <h4 className="font-semibold text-sm text-slate-600">
                          {uploadedAnalysisResult.schemeNameTamil}
                        </h4>
                      )}
                      <p className="text-xs text-slate-500 font-semibold">
                        🏢 {uploadedAnalysisResult.ministry}
                      </p>
                    </div>

                    {/* Objective */}
                    <div className="space-y-1">
                      <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">Parsed Objective</p>
                      <p className="text-sm text-slate-700 leading-relaxed">
                        {uploadedAnalysisResult.mainObjective}
                      </p>
                    </div>

                    {/* VERDICT CARD */}
                    <div className={`p-4 rounded-xl border ${
                      uploadedAnalysisResult.citizenEligibilityStatus === "Eligible"
                        ? "bg-emerald-50 border-emerald-200 text-emerald-900"
                        : uploadedAnalysisResult.citizenEligibilityStatus === "Not Eligible"
                          ? "bg-red-50 border-red-200 text-red-900"
                          : "bg-amber-50 border-amber-200 text-amber-900"
                    }`}>
                      <p className="text-xs font-bold uppercase tracking-wider">
                        {t("eligibilityStatus")}
                      </p>
                      <p className="text-lg font-bold flex items-center gap-1.5 mt-0.5">
                        <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
                        <span>
                          {uploadedAnalysisResult.citizenEligibilityStatus === "Eligible"
                            ? t("verdictEligible")
                            : uploadedAnalysisResult.citizenEligibilityStatus === "Not Eligible"
                              ? t("verdictNotEligible")
                              : t("verdictUndetermined")}
                        </span>
                      </p>
                      <p className="text-xs mt-2 leading-relaxed">
                        {uploadedAnalysisResult.citizenEligibilityExplanation}
                      </p>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      {/* Key Benefits */}
                      <div className="bg-slate-50 p-3 rounded-xl border border-slate-200/60 space-y-1">
                        <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">{t("benefitLabel")}</span>
                        <p className="text-xs text-slate-800 leading-relaxed font-semibold">
                          {uploadedAnalysisResult.keyBenefits}
                        </p>
                      </div>

                      {/* Criteria */}
                      <div className="bg-slate-50 p-3 rounded-xl border border-slate-200/60 space-y-1">
                        <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">Qualifications Required</span>
                        <p className="text-xs text-slate-800 leading-relaxed">
                          {uploadedAnalysisResult.eligibilityCriteriaSummary}
                        </p>
                      </div>
                    </div>

                    {/* How to Apply */}
                    <div className="space-y-1 bg-slate-50 p-4 rounded-xl border border-slate-100">
                      <span className="text-xs font-bold text-slate-600 uppercase tracking-wider block">{t("stepsLabel")}</span>
                      <p className="text-xs text-slate-700 leading-relaxed whitespace-pre-wrap">
                        {uploadedAnalysisResult.stepsToApply}
                      </p>
                    </div>

                    {/* Critical dates */}
                    {uploadedAnalysisResult.criticalDates && (
                      <div className="bg-amber-50/60 border border-amber-200/60 p-3.5 rounded-xl flex items-center gap-2">
                        <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0" />
                        <div>
                          <p className="text-xs font-bold text-amber-900 uppercase tracking-wider">{t("criticalDates")}</p>
                          <p className="text-xs text-amber-800 mt-0.5">{uploadedAnalysisResult.criticalDates}</p>
                        </div>
                      </div>
                    )}

                  </div>
                )}

              </div>

            </div>
          </div>
        )}

        {/* ----------------- TAB: SEVAI AI CHATBOT ----------------- */}
        {activeTab === "chat" && (
          <div className="max-w-4xl mx-auto space-y-6 animate-fade-in">
            <div className="text-center space-y-1">
              <h2 className="text-3xl font-display font-bold text-slate-900">
                {t("chatTitle")}
              </h2>
              <p className="text-slate-600 text-sm">
                {t("chatSubtitle")}
              </p>
            </div>

            {/* Chat conversation area */}
            <div className="bg-white border border-slate-200 rounded-3xl shadow-sm flex flex-col h-[550px] overflow-hidden">
              
              {/* Header profile info */}
              <div className="bg-slate-900 text-white px-5 py-3 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="bg-brand-500 p-1.5 rounded-lg text-white">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm">Sevai AI (சேவை ஏஐ)</h3>
                    <p className="text-[10px] text-brand-300">Empathy & Grounded search assistant</p>
                  </div>
                </div>
                
                {/* Active user state context summary */}
                <div className="text-right hidden sm:block">
                  <p className="text-[10px] text-slate-400">Context active</p>
                  <p className="text-xs font-bold text-emerald-400">
                    {profile.occupation} | age {profile.age}
                  </p>
                </div>
              </div>

              {/* Message scroll container */}
              <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4 bg-slate-50">
                {chatMessages.map((msg) => {
                  const isBot = msg.role === "assistant";
                  return (
                    <div 
                      key={msg.id} 
                      className={`flex gap-3 max-w-[85%] ${isBot ? "mr-auto" : "ml-auto flex-row-reverse"}`}
                    >
                      {/* Avatar icon */}
                      <div className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 text-xs font-bold ${
                        isBot ? "bg-slate-900 text-white" : "bg-brand-600 text-white"
                      }`}>
                        {isBot ? "🤖" : "👤"}
                      </div>

                      {/* Text content bubble */}
                      <div className="space-y-1">
                        <div className={`p-4 rounded-2xl text-sm leading-relaxed whitespace-pre-wrap shadow-xs ${
                          isBot 
                            ? "bg-white text-slate-800 rounded-tl-none border border-slate-200" 
                            : "bg-brand-600 text-white rounded-tr-none"
                        }`}>
                          {msg.content}
                        </div>
                        <p className={`text-[9px] text-slate-400 font-semibold px-1 ${!isBot ? "text-right" : ""}`}>
                          {msg.timestamp}
                        </p>
                      </div>
                    </div>
                  );
                })}

                {/* Simulated/active loader while bot replies */}
                {isChatSending && (
                  <div className="flex gap-3 mr-auto max-w-[80%]">
                    <div className="w-8 h-8 rounded-xl bg-slate-900 text-white flex items-center justify-center text-xs">
                      🤖
                    </div>
                    <div className="p-3 bg-white border border-slate-200 text-slate-500 rounded-2xl rounded-tl-none text-xs flex items-center gap-2">
                      <Loader2 className="w-4 h-4 animate-spin text-brand-600" />
                      <span>Sevai AI is composing a personalized guidance...</span>
                    </div>
                  </div>
                )}

                <div ref={chatBottomRef} />
              </div>

              {/* Chat Input form footer */}
              <div className="p-4 border-t border-slate-200 bg-white">
                <form onSubmit={handleSendChatMessage} className="flex gap-2 items-center">
                  
                  {/* Mic Voice trigger for chat input */}
                  <button
                    type="button"
                    onClick={() => startVoiceInput("chat")}
                    className={`p-3 rounded-xl transition-all cursor-pointer flex items-center justify-center ${
                      isListeningChat 
                        ? "bg-red-100 text-red-600 animate-pulse border border-red-300" 
                        : "bg-slate-100 hover:bg-slate-200 text-slate-600"
                    }`}
                    title={lang === "ta" ? "பேசி உள்ளீடு செய்ய" : "Speak using Voice Input"}
                  >
                    {isListeningChat ? <MicOff className="w-5 h-5 animate-pulse" /> : <Mic className="w-5 h-5" />}
                  </button>

                  <input
                    id="chat-user-input"
                    type="text"
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    placeholder={t("chatPlaceholder")}
                    className="flex-1 px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent text-sm transition-all"
                  />

                  <button
                    id="submit-chat-message-btn"
                    type="submit"
                    disabled={isChatSending || !chatInput.trim()}
                    className="bg-brand-600 hover:bg-brand-700 disabled:opacity-50 text-white p-3 rounded-xl transition-all flex items-center justify-center cursor-pointer"
                  >
                    <Send className="w-5 h-5" />
                  </button>
                </form>

                {isListeningChat && (
                  <p className="text-xs text-red-600 font-semibold animate-pulse mt-2 text-center">
                    🎙️ {lang === "ta" ? "பேசுங்கள், தமிழ் பதிவு செய்யப்படுகிறது..." : "System is capturing your microphone..."}
                  </p>
                )}
              </div>

            </div>
          </div>
        )}

        {/* ----------------- TAB: CONTACT & FEEDBACK / PITCH ----------------- */}
        {activeTab === "contact" && (
          <div className="max-w-4xl mx-auto space-y-8 animate-fade-in">
            
            {/* Split layout for form and hackathon pitch details */}
            <div className="grid md:grid-cols-12 gap-8 items-start">
              
              {/* Feedback Form Card */}
              <div className="md:col-span-7 bg-white border border-slate-200 p-6 rounded-2xl shadow-xs space-y-5">
                <div className="space-y-1">
                  <h3 className="font-display font-bold text-xl text-slate-900">
                    {t("contactTitle")}
                  </h3>
                  <p className="text-slate-600 text-xs">
                    {t("contactSubtitle")}
                  </p>
                </div>

                {feedbackSuccessMsg && (
                  <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-xl text-xs font-semibold">
                    ✅ {feedbackSuccessMsg}
                  </div>
                )}

                <form onSubmit={handleFeedbackSubmit} className="space-y-4">
                  
                  <div className="space-y-1">
                    <label htmlFor="feedback-email" className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                      {t("yourEmail")}
                    </label>
                    <input
                      id="feedback-email"
                      type="email"
                      value={feedbackEmail}
                      onChange={(e) => setFeedbackEmail(e.target.value)}
                      placeholder="e.g. citizen@gmail.com"
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent text-sm transition-all"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <label htmlFor="feedback-msg" className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                      {t("feedbackMsg")}
                    </label>
                    <textarea
                      id="feedback-msg"
                      rows={5}
                      value={feedbackMessage}
                      onChange={(e) => setFeedbackMessage(e.target.value)}
                      placeholder="Write your suggestions..."
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent text-sm transition-all text-slate-850"
                      required
                    ></textarea>
                  </div>

                  <button
                    id="submit-feedback-btn"
                    type="submit"
                    className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-3 rounded-xl transition-all cursor-pointer shadow-xs"
                  >
                    {t("submitFeedback")}
                  </button>

                </form>
              </div>

              {/* Hackathon Pitch Column details */}
              <div className="md:col-span-5 space-y-6">
                
                {/* One line pitch card */}
                <div className="bg-slate-900 text-white p-5 rounded-2xl border border-slate-800 space-y-3 shadow-md">
                  <div className="flex items-center gap-2 text-amber-400">
                    <Sparkles className="w-5 h-5" />
                    <span className="text-xs font-bold uppercase tracking-wider">{t("pitchLabel")}</span>
                  </div>
                  <blockquote className="text-sm italic text-slate-200 leading-relaxed font-serif">
                    "{t("oneLinePitch")}"
                  </blockquote>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Designed as a hackathon showcase utility to allow underprivileged or rural citizens discover benefits instantly, bridging gaps with dynamic model translations.
                  </p>
                </div>

                {/* Team / Technical Stack info */}
                <div className="bg-white border border-slate-200 p-5 rounded-2xl space-y-4">
                  <h4 className="font-display font-bold text-slate-950 text-sm border-b border-slate-100 pb-2">
                    🛠️ Project Architecture Details
                  </h4>
                  
                  <div className="space-y-3">
                    {[
                      { component: "Primary AI Engine", value: "Gemini 3.5 Flash Model" },
                      { component: "Search Verification", value: "Grounded Google Search Tools" },
                      { component: "Frontend Layout", value: "React 19 & Tailwind CSS 4" },
                      { component: "Backend Microservices", value: "Node Express REST Framework" },
                      { component: "Client Persistence", value: "Secure Local Cache Store" },
                    ].map((tech, idx) => (
                      <div key={idx} className="flex justify-between items-center text-xs">
                        <span className="text-slate-500 font-semibold">{tech.component}</span>
                        <span className="font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded-md">
                          {tech.value}
                        </span>
                      </div>
                    ))}
                  </div>

                  <div className="bg-emerald-50 p-3.5 rounded-xl text-xs text-emerald-900 leading-relaxed font-semibold">
                    💡 <strong>Pro-Tip:</strong> Try testing with the English-Tamil toggle. Or use the <strong>New Scheme Analyzer</strong> to parse customized circulars.
                  </div>
                </div>

              </div>

            </div>
          </div>
        )}

      </main>

      {/* ----------------- GLOBAL FOOTER ----------------- */}
      <footer className="bg-slate-900 border-t border-slate-800 py-6 px-4 mt-12 print:hidden text-center text-slate-400 text-xs">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="text-left space-y-1">
            <p className="font-bold text-slate-200 flex items-center gap-1">
              <span>Sevai AI Government Scheme Finder</span>
              <span className="text-emerald-400">● Live Active</span>
            </p>
            <p className="text-slate-500">
              A premium, full-stack welfare discovering engine powered by Gemini AI and real-time grounding.
            </p>
          </div>

          <div className="flex gap-4">
            <button onClick={() => setActiveTab("home")} className="hover:text-slate-200">Home</button>
            <button onClick={() => setActiveTab("finder")} className="hover:text-slate-200">Eligibility Finder</button>
            <button onClick={() => setActiveTab("chat")} className="hover:text-slate-200">AI Chatbot</button>
          </div>
        </div>
      </footer>

    </div>
  );
}
